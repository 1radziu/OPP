#ifndef SAMOCHOD_H
#define SAMOCHOD_H

#include <string>

class Samochod {
private:
    std::string marka;
    std::string model;
    int rokProdukcji;
    double cena;
    std::string rodzajPaliwa;
    int przebieg;
    std::string kolor;
    bool jestDostepny;
    std::string VIN;

public:
    Samochod(const std::string& marka, const std::string& model, int rokProdukcji,
        double cena, const std::string& rodzajPaliwa, int przebieg,
        const std::string& kolor, bool jestDostepny, const std::string& VIN);


    std::string getMarka() const;
    void setMarka(const std::string& newBrand);

    std::string getModel() const;
    void setModel(const std::string& newModel);

    int getRokProdukcji() const;
    void setRokProdukcji(int newYear);

    double getCena() const;
    void setCena(double newPrice);

    std::string getRodzajPaliwa() const;
    void setRodzajPaliwa(const std::string& newFuelType);

    int getPrzebieg() const;
    void setPrzebieg(int newMileage);

    std::string getKolor() const;
    void setKolor(const std::string& newColor);

    bool getJestDostepny() const;
    void setJestDostepny(bool isAvailable);

    std::string getVIN() const;
    void setVIN(const std::string& newVIN);


};

#endif
