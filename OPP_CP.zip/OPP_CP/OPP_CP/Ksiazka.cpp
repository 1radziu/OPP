#include "Ksiazka.h"

Ksiazka::Ksiazka(const std::string& tytul, const std::string& autor, int rokWydania,
    const std::string& ISBN, const std::string& gatunek, int liczbaStron,
    const std::string& wydawca, bool jestDostepna)
    : tytul(tytul), autor(autor), rokWydania(rokWydania),
    ISBN(ISBN), gatunek(gatunek), liczbaStron(liczbaStron),
    wydawca(wydawca), jestDostepna(jestDostepna) {
 
}

std::string Ksiazka::getTytul() const {
    return tytul;
}

void Ksiazka::setTytul(const std::string& newTitle) {
    tytul = newTitle;
}

std::string Ksiazka::getAutor() const {
    return autor;
}

void Ksiazka::setAutor(const std::string& newAuthor) {
    autor = newAuthor;
}

int Ksiazka::getRokWydania() const {
    return rokWydania;
}

void Ksiazka::setRokWydania(int newYear) {
    rokWydania = newYear;
}

std::string Ksiazka::getISBN() const {
    return ISBN;
}

void Ksiazka::setISBN(const std::string& newISBN) {
    ISBN = newISBN;
}

std::string Ksiazka::getGatunek() const {
    return gatunek;
}

void Ksiazka::setGatunek(const std::string& newGenre) {
    gatunek = newGenre;
}

int Ksiazka::getLiczbaStron() const {
    return liczbaStron;
}

void Ksiazka::setLiczbaStron(int newPageCount) {
    liczbaStron = newPageCount;
}

std::string Ksiazka::getWydawca() const {
    return wydawca;
}

void Ksiazka::setWydawca(const std::string& newPublisher) {
    wydawca = newPublisher;
}

bool Ksiazka::getJestDostepna() const {
    return jestDostepna;
}

void Ksiazka::setJestDostepna(bool isAvailable) {
    jestDostepna = isAvailable;
}

