﻿#include <iostream>

#include "Produkt.h"
#include "Samochod.h"
#include "Ksiazka.h"

int main() {
    Produkt produkt("Laptop", 999.99, "Dell", 10, "Laptop o wysokiej wydajności", true, "Elektronika", "DLT123");
    Samochod samochod("Toyota", "Camry", 2022, 25000.0, "Benzyna", 15000, "Srebrny", true, "JTDB12345678901234");
    Ksiazka ksiazka("Wielki Gatsby", "F. Scott Fitzgerald", 1925, "978-3-16-148410-0", "Klasyczna", 200, "Scribner", true);


    std::cout << "Nazwa produktu: " << produkt.getNazwa() << std::endl;
    std::cout << "Marka samochodu: " << samochod.getMarka() << std::endl;
    std::cout << "Tytuł książki: " << ksiazka.getTytul() << std::endl;

    produkt.setCena(899.99);
    samochod.setKolor("Czerwony");
    ksiazka.setRokWydania(1926);

    return 0;
}


