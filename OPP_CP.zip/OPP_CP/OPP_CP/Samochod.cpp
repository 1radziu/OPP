#include "Samochod.h"

Samochod::Samochod(const std::string& marka, const std::string& model, int rokProdukcji,
    double cena, const std::string& rodzajPaliwa, int przebieg,
    const std::string& kolor, bool jestDostepny, const std::string& VIN)
    : marka(marka), model(model), rokProdukcji(rokProdukcji), cena(cena),
    rodzajPaliwa(rodzajPaliwa), przebieg(przebieg), kolor(kolor),
    jestDostepny(jestDostepny), VIN(VIN) {

}

std::string Samochod::getMarka() const {
    return marka;
}

void Samochod::setMarka(const std::string& newBrand) {
    marka = newBrand;
}

std::string Samochod::getModel() const {
    return model;
}

void Samochod::setModel(const std::string& newModel) {
    model = newModel;
}

int Samochod::getRokProdukcji() const {
    return rokProdukcji;
}

void Samochod::setRokProdukcji(int newYear) {
    rokProdukcji = newYear;
}

double Samochod::getCena() const {
    return cena;
}

void Samochod::setCena(double newPrice) {
    cena = newPrice;
}

std::string Samochod::getRodzajPaliwa() const {
    return rodzajPaliwa;
}

void Samochod::setRodzajPaliwa(const std::string& newFuelType) {
    rodzajPaliwa = newFuelType;
}

int Samochod::getPrzebieg() const {
    return przebieg;
}

void Samochod::setPrzebieg(int newMileage) {
    przebieg = newMileage;
}

std::string Samochod::getKolor() const {
    return kolor;
}

void Samochod::setKolor(const std::string& newColor) {
    kolor = newColor;
}

bool Samochod::getJestDostepny() const {
    return jestDostepny;
}

void Samochod::setJestDostepny(bool isAvailable) {
    jestDostepny = isAvailable;
}

std::string Samochod::getVIN() const {
    return VIN;
}

void Samochod::setVIN(const std::string& newVIN) {
    VIN = newVIN;
}


