#include "Produkt.h"

Produkt::Produkt(const std::string& nazwa, double cena, const std::string& producent,
    int iloscNaStanie, const std::string& opis,
    bool jestDostepny, const std::string& kategoria, const std::string& SKU)
    : nazwa(nazwa), cena(cena), producent(producent),
    iloscNaStanie(iloscNaStanie), opis(opis),
    jestDostepny(jestDostepny), kategoria(kategoria), SKU(SKU) {
   
}

std::string Produkt::getNazwa() const {
    return nazwa;
}

void Produkt::setNazwa(const std::string& newName) {
    nazwa = newName;
}

double Produkt::getCena() const {
    return cena;
}

void Produkt::setCena(double newPrice) {
    cena = newPrice;
}

std::string Produkt::getProducent() const {
    return producent;
}

void Produkt::setProducent(const std::string& newManufacturer) {
    producent = newManufacturer;
}

int Produkt::getIloscNaStanie() const {
    return iloscNaStanie;
}

void Produkt::setIloscNaStanie(int newQuantity) {
    iloscNaStanie = newQuantity;
}

std::string Produkt::getOpis() const {
    return opis;
}

void Produkt::setOpis(const std::string& newDescription) {
    opis = newDescription;
}

bool Produkt::getJestDostepny() const {
    return jestDostepny;
}

void Produkt::setJestDostepny(bool isAvailable) {
    jestDostepny = isAvailable;
}

std::string Produkt::getKategoria() const {
    return kategoria;
}

void Produkt::setKategoria(const std::string& newCategory) {
    kategoria = newCategory;
}

std::string Produkt::getSKU() const {
    return SKU;
}

void Produkt::setSKU(const std::string& newSKU) {
    SKU = newSKU;
}



