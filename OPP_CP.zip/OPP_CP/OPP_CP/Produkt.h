#ifndef PRODUKT_H
#define PRODUKT_H

#include <string>

class Produkt {
private:
    std::string nazwa;
    double cena;
    std::string producent;
    int iloscNaStanie;
    std::string opis;
    bool jestDostepny;
    std::string kategoria;
    std::string SKU;

public:
    Produkt(const std::string& nazwa, double cena, const std::string& producent,
        int iloscNaStanie, const std::string& opis,
        bool jestDostepny, const std::string& kategoria, const std::string& SKU);

    std::string getNazwa() const;
    void setNazwa(const std::string& newName);

    double getCena() const;
    void setCena(double newPrice);

    std::string getProducent() const;
    void setProducent(const std::string& newManufacturer);

    int getIloscNaStanie() const;
    void setIloscNaStanie(int newQuantity);

    std::string getOpis() const;
    void setOpis(const std::string& newDescription);

    bool getJestDostepny() const;
    void setJestDostepny(bool isAvailable);

    std::string getKategoria() const;
    void setKategoria(const std::string& newCategory);

    std::string getSKU() const;
    void setSKU(const std::string& newSKU);

};

#endif


