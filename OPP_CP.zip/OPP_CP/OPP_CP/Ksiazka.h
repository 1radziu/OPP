#ifndef KSIAZKA_H
#define KSIAZKA_H

#include <string>

class Ksiazka {
private:
    std::string tytul;
    std::string autor;
    int rokWydania;
    std::string ISBN;
    std::string gatunek;
    int liczbaStron;
    std::string wydawca;
    bool jestDostepna;

public:
    Ksiazka(const std::string& tytul, const std::string& autor, int rokWydania,
        const std::string& ISBN, const std::string& gatunek, int liczbaStron,
        const std::string& wydawca, bool jestDostepna);

    
    std::string getTytul() const;
    void setTytul(const std::string& newTitle);

    std::string getAutor() const;
    void setAutor(const std::string& newAuthor);

    int getRokWydania() const;
    void setRokWydania(int newYear);

    std::string getISBN() const;
    void setISBN(const std::string& newISBN);

    std::string getGatunek() const;
    void setGatunek(const std::string& newGenre);

    int getLiczbaStron() const;
    void setLiczbaStron(int newPageCount);

    std::string getWydawca() const;
    void setWydawca(const std::string& newPublisher);

    bool getJestDostepna() const;
    void setJestDostepna(bool isAvailable);


};

#endif
