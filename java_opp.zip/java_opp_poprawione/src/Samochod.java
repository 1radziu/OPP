public class Samochod {
    private String marka;
    private String model;
    private int rok;
    private double cena;
    private int przebieg;
    private String kolor;
    private String typPaliwa;
    private boolean czyAutomat;

    public Samochod(String marka, String model, int rok, double cena, int przebieg, String kolor, String typPaliwa, boolean czyAutomat) {
        this.marka = marka;
        this.model = model;
        this.rok = rok;
        this.cena = cena;
        this.przebieg = przebieg;
        this.kolor = kolor;
        this.typPaliwa = typPaliwa;
        this.czyAutomat = czyAutomat;
    }

    // Gettery i settery dla wszystkich pól
    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getRok() {
        return rok;
    }

    public void setRok(int rok) {
        this.rok = rok;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public int getPrzebieg() {
        return przebieg;
    }

    public void setPrzebieg(int przebieg) {
        this.przebieg = przebieg;
    }

    public String getKolor() {
        return kolor;
    }

    public void setKolor(String kolor) {
        this.kolor = kolor;
    }

    public String getTypPaliwa() {
        return typPaliwa;
    }

    public void setTypPaliwa(String typPaliwa) {
        this.typPaliwa = typPaliwa;
    }

    public boolean isCzyAutomat() {
        return czyAutomat;
    }

    public void setCzyAutomat(boolean czyAutomat) {
        this.czyAutomat = czyAutomat;
    }
}
