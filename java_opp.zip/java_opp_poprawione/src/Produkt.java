public class Produkt {
    private String nazwa;
    private double cena;
    private int iloscWStanie;
    private String opis;
    private String kategoria;
    private String marka;
    private boolean jestDostepny;
    private String producent;

    public Produkt(String nazwa, double cena, int iloscWStanie, String opis, String kategoria, String marka, boolean jestDostepny, String producent) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.iloscWStanie = iloscWStanie;
        this.opis = opis;
        this.kategoria = kategoria;
        this.marka = marka;
        this.jestDostepny = jestDostepny;
        this.producent = producent;
    }

    // Gettery i settery dla wszystkich pól
    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public int getIloscWStanie() {
        return iloscWStanie;
    }

    public void setIloscWStanie(int iloscWStanie) {
        this.iloscWStanie = iloscWStanie;
    }

    public String getOpis() {
        return opis;
    }
    public void  setOpis(String opis) {this.opis = opis;}

    public String getKategoria() {return kategoria;}
    public void setKategoria(String kategoria) {this.kategoria = kategoria;}

    public String getMarka() {return marka;}
    public void setMarka(String marka) {this.marka = marka;}


    public boolean isJestDostepny() {
        return jestDostepny;
    }

    public void setJestDostepny(boolean jestDostepny) {
        this.jestDostepny = jestDostepny;
    }



    public String getproducent() {
        return producent;
    }
    public void  setProducent(String producent) {this.producent = producent;}


}


