public class Ksiazka {
    private String tytul;
    private String autor;
    private int rokWydania;
    private double cena;
    private int liczbaStron;
    private String wydawnictwo;
    private String gatunek;
    private boolean jestDostepna;


    public Ksiazka(String tytul, String autor, int rokWydania, double cena, int liczbaStron, String wydawnictwo, String gatunek, boolean jestDostepna) {
        this.tytul = tytul;
        this.autor = autor;
        this.rokWydania = rokWydania;
        this.cena = cena;
        this.liczbaStron = liczbaStron;
        this.wydawnictwo = wydawnictwo;
        this.gatunek = gatunek;
        this.jestDostepna = jestDostepna;
    }

    // Gettery i settery dla wszystkich pól
    public String getTytul() {
        return tytul;
    }

    public void setTytul(String tytul) {
        this.tytul = tytul;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getRokWydania() {
        return rokWydania;
    }

    public void setRokWydania(int rokWydania) {
        this.rokWydania = rokWydania;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public int getLiczbaStron() {
        return liczbaStron;
    }

    public void setLiczbaStron(int liczbaStron) {
        this.liczbaStron = liczbaStron;
    }

    public String getWydawnictwo() {
        return wydawnictwo;
    }

    public void setWydawnictwo(String wydawnictwo) {
        this.wydawnictwo = wydawnictwo;
    }

    public String getGatunek() {
        return gatunek;
    }

    public void setGatunek(String gatunek) {
        this.gatunek = gatunek;
    }

    public boolean isJestDostepna() {
        return jestDostepna;
    }

    public void setJestDostepna(boolean jestDostepna) {
        this.jestDostepna = jestDostepna;
    }
}

