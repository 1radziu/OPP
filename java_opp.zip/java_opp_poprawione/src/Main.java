public class Main {
    public static void main(String[] args) {

        Ksiazka ksiazka1 = new Ksiazka("Wiedźmin", "Andrzej Sapkowski", 1993, 29.99, 350, "SuperNOWA", "Fantasy", true);
        Samochod samochod1 = new Samochod("Volkswagen", "Golf", 2021, 89999.99, 0, "Czarny", "Benzyna",false);
        Produkt produkt1 = new Produkt("Coca-Cola",12,581,"Sam cukier","Napój","Coca-Cola",true,"The Coca-Cola Company");
        System.out.println("Informacje o książkach:");
        wyswietlInformacjeOKsiazce(ksiazka1);

        System.out.println("Informacje o samochodzie: ");
        wyswietlInformacjeOSamochodzie(samochod1);

        System.out.println("Informacje o produktach: ");
        wyswietlInformacjeOProdukcie(produkt1);


    }

    public static void wyswietlInformacjeOKsiazce(Ksiazka ksiazka) {
        System.out.println("Tytuł: " + ksiazka.getTytul());
        System.out.println("Autor: " + ksiazka.getAutor());
        System.out.println("Rok wydania: " + ksiazka.getRokWydania());
        System.out.println("Cena: " + ksiazka.getCena());
        System.out.println("Liczba stron: " + ksiazka.getLiczbaStron());
        System.out.println("Wydawnictwo: " + ksiazka.getWydawnictwo());
        System.out.println("Gatunek: " + ksiazka.getGatunek());
        System.out.println("Dostępność: " + (ksiazka.isJestDostepna() ? "Dostępny" : "Niedostępny"));
        System.out.println();
    }

    public static void wyswietlInformacjeOSamochodzie(Samochod samochod) {
        System.out.println("Marka: " + samochod.getMarka());
        System.out.println("Model: " + samochod.getModel());
        System.out.println("rok: " + samochod.getRok());
        System.out.println("cena: " + samochod.getCena());
        System.out.println("przebieg: " + samochod.getPrzebieg());
        System.out.println("kolor: " + samochod.getKolor());
        System.out.println("typPaliwa: " + samochod.getTypPaliwa());
        System.out.println("czyAutomat: " + (samochod.isCzyAutomat() ? "Dostępna" : "Niedostępna"));
        System.out.println();
    }

    public static void wyswietlInformacjeOProdukcie(Produkt produkt) {
        System.out.println("Nazwa: " + produkt.getNazwa());
        System.out.println("Cena: " + produkt.getCena());
        System.out.println("ilosc " + produkt.getIloscWStanie());
        System.out.println("opis: " + produkt.getOpis());
        System.out.println("kategoria: " + produkt.getKategoria());
        System.out.println("marka: " + produkt.getMarka());
        System.out.println("jestDostępny: " + (produkt.isJestDostepny() ? "Dostępny" : "Niedostępny"));
        System.out.println("producent: " + produkt.getproducent());
        System.out.println();
    }





}
