﻿public class Ksiazka
{
    public string Tytul { get; set; }
    public string Autor { get; set; }
    public int Strony { get; set; }
    public double Cena { get; set; }
    public string Wydawnictwo { get; set; }
    public string ISBN { get; set; }
    public string Jezyk { get; set; }
    public bool TwardaOkładka { get; set; }
    public int RokWydania { get; set; }

    public Ksiazka(string tytul, string autor, int strony, double cena, string wydawnictwo, string isbn, string jezyk, bool twardaOkładka, int rokWydania)
    {
        Tytul = tytul;
        Autor = autor;
        Strony = strony;
        Cena = cena;
        Wydawnictwo = wydawnictwo;
        ISBN = isbn;
        Jezyk = jezyk;
        TwardaOkładka = twardaOkładka;
        RokWydania = rokWydania;
    }
}
