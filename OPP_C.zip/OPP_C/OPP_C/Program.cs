﻿class Program
{
    static void Main()
    {
      
        Ksiazka ksiazka = new Ksiazka("Władca Pierścieni", "J.R.R. Tolkien", 1000, 49.99, "Wydawnictwo XYZ", "978-3-16-148410-0", "Polski", true, 2005);
        Produkt produkt = new Produkt("Telewizor LCD", 799.99, 5, "Elektronika", "Sony", "Duży telewizor LCD", new DateTime(2023, 1, 15), new DateTime(2025, 1, 15), "1234567890123");
        Samochod samochod = new Samochod("Toyota", "Camry", 2022, 24999.99, "Czerwony", 180, 2000, true, "WY12345");

      
        Console.WriteLine("Książka: {0} autorstwa {1}, {2} stron, cena: {3:C}", ksiazka.Tytul, ksiazka.Autor, ksiazka.Strony, ksiazka.Cena);
        Console.WriteLine("Produkt: {0}, cena: {1:C}, ilość: {2}", produkt.Nazwa, produkt.Cena, produkt.Ilosc);
        Console.WriteLine("Samochód: {0} {1}, rok produkcji: {2}, cena: {3:C}", samochod.Marka, samochod.Model, samochod.RokProdukcji, samochod.Cena);
    }
}