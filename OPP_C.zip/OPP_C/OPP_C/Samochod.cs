﻿public class Samochod
{
    public string Marka { get; set; }
    public string Model { get; set; }
    public int RokProdukcji { get; set; }
    public double Cena { get; set; }
    public string Kolor { get; set; }
    public int MocSilnika { get; set; }
    public int PojemnoscSilnika { get; set; }
    public bool AutomatycznaSkrzynia { get; set; }
    public string NumerRejestracyjny { get; set; }

    public Samochod(string marka, string model, int rokProdukcji, double cena, string kolor, int mocSilnika, int pojemnoscSilnika, bool automatycznaSkrzynia, string numerRejestracyjny)
    {
        Marka = marka;
        Model = model;
        RokProdukcji = rokProdukcji;
        Cena = cena;
        Kolor = kolor;
        MocSilnika = mocSilnika;
        PojemnoscSilnika = pojemnoscSilnika;
        AutomatycznaSkrzynia = automatycznaSkrzynia;
        NumerRejestracyjny = numerRejestracyjny;
    }
}
