﻿public class Produkt
{
    public string Nazwa { get; set; }
    public double Cena { get; set; }
    public int Ilosc { get; set; }
    public string Kategoria { get; set; }
    public string Producent { get; set; }
    public string Opis { get; set; }
    public DateTime DataProdukcji { get; set; }
    public DateTime DataWaznosci { get; set; }
    public string KodKreskowy { get; set; }

    public Produkt(string nazwa, double cena, int ilosc, string kategoria, string producent, string opis, DateTime dataProdukcji, DateTime dataWaznosci, string kodKreskowy)
    {
        Nazwa = nazwa;
        Cena = cena;
        Ilosc = ilosc;
        Kategoria = kategoria;
        Producent = producent;
        Opis = opis;
        DataProdukcji = dataProdukcji;
        DataWaznosci = dataWaznosci;
        KodKreskowy = kodKreskowy;
    }
}